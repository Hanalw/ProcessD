
require("./UnisightProcessDocuments.module.css");
const styles = {
  unisightProcessDocuments: 'unisightProcessDocuments_b9b71963',
  container: 'container_b9b71963',
  row: 'row_b9b71963',
  resultsRow: 'resultsRow_b9b71963',
  column: 'column_b9b71963',
  'ms-Grid': 'ms-Grid_b9b71963',
  resultsColumn: 'resultsColumn_b9b71963',
  tabList: 'tabList_b9b71963',
  docLinks: 'docLinks_b9b71963',
  links: 'links_b9b71963',
  description: 'description_b9b71963',
  contextualMenu: 'contextualMenu_b9b71963',
  contextualMenuIcon: 'contextualMenuIcon_b9b71963',
  filterDiv: 'filterDiv_b9b71963',
  cleardiv: 'cleardiv_b9b71963',
  filterChip: 'filterChip_b9b71963',
  filterChipIcon: 'filterChipIcon_b9b71963',
  filterpanel: 'filterpanel_b9b71963',
  checkboxes: 'checkboxes_b9b71963',
  buttons: 'buttons_b9b71963',
  tabSpinner: 'tabSpinner_b9b71963'
};

export default styles;
